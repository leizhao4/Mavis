package Color;

use warnings;
use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);
require Exporter;
require AutoLoader;

@ISA     = qw(Exporter AutoLoader);
@EXPORT  = qw();
$VERSION = '1.0';

### Constructor ###

sub new {
    my ($class, $r, $g, $b) = @_;
    my $self = bless { _r => $r, _g => $g, _b => $b }, $class;
    return $self;
}

### Accessors ###

sub r { $_[0] -> {_r} }
sub g { $_[0] -> {_g} }
sub b { $_[0] -> {_b} }

### Methods ###

sub to_html_3 {
  my $self = shift;
  my ($r, $g, $b) = ($self->r, $self->g, $self->b);
  $r = 0 if $r < 0; $g = 0 if $g < 0; $b = 0 if $b < 0; 
  $r = 1 if $r > 1; $g = 1 if $g > 1; $b = 1 if $b > 1; 
  my $html = sprintf "#%01x%01x%01x", int($r * 4) * 3.99, int($g * 4) * 3.99, int($b * 4) * 3.99;
  return $html;
}

sub to_html {
  my $self = shift;
  my ($r, $g, $b) = ($self->r, $self->g, $self->b);
  $r = 0 if $r < 0; $g = 0 if $g < 0; $b = 0 if $b < 0; 
  $r = 1 if $r > 1; $g = 1 if $g > 1; $b = 1 if $b > 1; 
  my $html = sprintf "#%02x%02x%02x", int($r * 255), int($g * 255), int($b * 255);
  return $html;
}

1;
__END__



